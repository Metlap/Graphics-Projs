var searchData=
[
  ['angle1',['angle1',['../clock_8cpp.html#aec1258e01412f85906ce6a4f5101e55b',1,'clock.cpp']]],
  ['angle2',['angle2',['../clock_8cpp.html#a944e6043842b8ea8abbfd88a69c0c7e9',1,'clock.cpp']]],
  ['angle3',['angle3',['../clock_8cpp.html#ae56ad854b3e055fa79066d65b6f541e4',1,'clock.cpp']]]
];
