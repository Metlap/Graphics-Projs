var searchData=
[
  ['pitch',['pitch',['../main_8cpp.html#a34c057a0378030db67bd6a129f37d938',1,'main.cpp']]]
];
