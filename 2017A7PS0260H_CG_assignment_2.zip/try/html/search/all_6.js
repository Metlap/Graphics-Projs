var searchData=
[
  ['getnormal',['GetNormal',['../class_obj_model_loader.html#a6b2aa4e718570359e6b654ad948c0aa3',1,'ObjModelLoader::GetNormal(float *coord1, float *coord2, float *coord3)'],['../class_obj_model_loader.html#ab7e5baa8ba27e56f828e1591f199f41b',1,'ObjModelLoader::GetNormal(float *coord1, float *coord2, float *coord3)'],['../class_obj_model_loader.html#ab7e5baa8ba27e56f828e1591f199f41b',1,'ObjModelLoader::GetNormal(float *coord1, float *coord2, float *coord3)']]]
];
