var searchData=
[
  ['cx',['cx',['../classprimitives.html#a46988726c6e4edf41a2c1d82d61565a5',1,'primitives']]],
  ['cy',['cy',['../classprimitives.html#ab924e60ca6c29f90e0830719e3966d6a',1,'primitives']]]
];
