var searchData=
[
  ['initializer',['initializer',['../classtree.html#a22e44bf95c32d54a66e2a91ca74decb4',1,'tree']]]
];
