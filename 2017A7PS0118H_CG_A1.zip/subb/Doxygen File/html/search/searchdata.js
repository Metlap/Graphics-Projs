var indexSectionsWithContent =
{
  0: "acdeinprtuxy",
  1: "enpt",
  2: "acdiptu",
  3: "crxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

