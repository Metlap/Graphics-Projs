var searchData=
[
  ['tidier',['Tidier',['../classtree.html#a3ab555be0649e279e130964b0c93e37a',1,'tree']]],
  ['tree',['tree',['../classtree.html',1,'tree'],['../classtree.html#a943d10650f183701ae0414689c9b9ee8',1,'tree::tree(vector&lt; int &gt; &amp;, int n)'],['../classtree.html#a529a530e3787fdaee02ed65cbf1f17ff',1,'tree::tree(int n, bool balanced)']]]
];
