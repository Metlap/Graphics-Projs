var searchData=
[
  ['use_5fas_5fcircle',['use_as_circle',['../classprimitives.html#a564d6b5f62f0958ed7773fdddd8ae05c',1,'primitives']]],
  ['use_5fas_5fline',['use_as_line',['../classprimitives.html#af30707ef8153f3770400b1b1126cae79',1,'primitives']]]
];
