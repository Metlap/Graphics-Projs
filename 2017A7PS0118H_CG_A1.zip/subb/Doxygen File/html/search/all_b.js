var searchData=
[
  ['y1',['y1',['../classprimitives.html#a98cbb319f4fe40b7987d2c7bdfd9fa6a',1,'primitives']]],
  ['y2',['y2',['../classprimitives.html#a77b49d02dc5171e8002222fe752c030e',1,'primitives']]]
];
