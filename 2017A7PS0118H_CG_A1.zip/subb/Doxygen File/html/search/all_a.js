var searchData=
[
  ['x2',['x2',['../classprimitives.html#ae3ac428b1195f1baf49fff4070c79280',1,'primitives']]]
];
