var searchData=
[
  ['radius',['radius',['../classprimitives.html#a0091dfd2f3dffce09b1e78884eeb8d79',1,'primitives']]],
  ['root',['root',['../classtree.html#ad397d4906e47149b98f769b3e81473ee',1,'tree']]]
];
