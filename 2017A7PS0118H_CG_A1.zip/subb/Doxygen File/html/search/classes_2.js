var searchData=
[
  ['primitives',['primitives',['../classprimitives.html',1,'']]]
];
