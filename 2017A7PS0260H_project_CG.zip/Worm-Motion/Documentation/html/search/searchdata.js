var indexSectionsWithContent =
{
  0: "abcdfiklmprstvw",
  1: "cdilpst",
  2: "bcdfklmprstw",
  3: "afmpstv"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

