var searchData=
[
  ['podium',['podium',['../dice_8h.html#a0be7a71e8386a334e2e20cda31d7157f',1,'dice.h']]],
  ['podiumfinal',['podiumFinal',['../classroom_8c.html#a45ddafcbdb98fd1d29ddb26cfaf9bc5f',1,'classroom.c']]],
  ['projection',['projection',['../classroom_8c.html#aeed201504c3705ba28fd8e9833270919',1,'classroom.c']]]
];
