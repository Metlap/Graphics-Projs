var searchData=
[
  ['window',['window',['../infra_8h.html#a0df472261d6be0025cff9bfa90d649ca',1,'infra.h']]]
];
