var searchData=
[
  ['slantpod',['slantpod',['../dice_8h.html#aa1e6f13aab22ccefc1f13b64b542cb8e',1,'dice.h']]],
  ['slantpod2',['slantpod2',['../dice_8h.html#ae73ecc65acd80c64216484622d662c79',1,'dice.h']]],
  ['slanttable',['slanttable',['../teacherTable_8h.html#a9d98a344d0ecd8149ee839a2475f5cd1',1,'teacherTable.h']]],
  ['stage',['stage',['../stage_8h.html#a6eac697931a876c4d14e9ec2e3d571bb',1,'stage.h']]],
  ['stage_2eh',['stage.h',['../stage_8h.html',1,'']]],
  ['stagebase',['stageBase',['../stage_8h.html#a5f404cbebcc75a0d679fc8811fc995aa',1,'stage.h']]],
  ['stagefinal',['stageFinal',['../classroom_8c.html#a0119467e1ce41ffb01b5081d6941efdf',1,'classroom.c']]],
  ['stagefront',['stagefront',['../stage_8h.html#aa51486b89232550e16da16edb789954b',1,'stage.h']]],
  ['stagetop',['stageTop',['../stage_8h.html#acbbbfd5cfddc527fceac371050899471',1,'stage.h']]],
  ['startx',['startx',['../classroom_8c.html#a8f0744c55ee97ebf34757f8499a66139',1,'classroom.c']]],
  ['starty',['starty',['../classroom_8c.html#a19e264821cbd530471c1cf985d7cd239',1,'classroom.c']]],
  ['studenttable',['studentTable',['../classroom_8c.html#ac70e5256caddd8938e124804765a924e',1,'classroom.c']]]
];
