var searchData=
[
  ['stagebase',['stageBase',['../stage_8h.html#a5f404cbebcc75a0d679fc8811fc995aa',1,'stage.h']]],
  ['stagetop',['stageTop',['../stage_8h.html#acbbbfd5cfddc527fceac371050899471',1,'stage.h']]],
  ['startx',['startx',['../classroom_8c.html#a8f0744c55ee97ebf34757f8499a66139',1,'classroom.c']]],
  ['starty',['starty',['../classroom_8c.html#a19e264821cbd530471c1cf985d7cd239',1,'classroom.c']]]
];
