var searchData=
[
  ['aspect',['aspect',['../classroom_8c.html#a973a4b0bc2b43673256177f0ba80e782',1,'classroom.c']]],
  ['axis',['axis',['../classroom_8c.html#a0574e179ce24d35f17992f5ad28235d6',1,'classroom.c']]]
];
