var searchData=
[
  ['kettle',['kettle',['../classroom_8c.html#afbf920de5c6b004c523e1f1044e6668e',1,'classroom.c']]],
  ['keys',['keys',['../classroom_8c.html#a5828243a546dac120bbeb4679ac4d828',1,'classroom.c']]]
];
