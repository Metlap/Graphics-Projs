var searchData=
[
  ['podbase',['podBase',['../dice_8h.html#ac7505723f07a9a671e0a0af308f45850',1,'dice.h']]],
  ['podmain',['podMain',['../dice_8h.html#a3d551777c669480cfeebaf1d42d16b29',1,'dice.h']]],
  ['podtop',['podTop',['../dice_8h.html#a280fedafbecc80caa7381bb159e9a7b7',1,'dice.h']]]
];
