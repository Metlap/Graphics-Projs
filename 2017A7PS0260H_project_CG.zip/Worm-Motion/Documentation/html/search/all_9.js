var searchData=
[
  ['podbase',['podBase',['../dice_8h.html#ac7505723f07a9a671e0a0af308f45850',1,'dice.h']]],
  ['podium',['podium',['../dice_8h.html#a0be7a71e8386a334e2e20cda31d7157f',1,'dice.h']]],
  ['podiumfinal',['podiumFinal',['../classroom_8c.html#a45ddafcbdb98fd1d29ddb26cfaf9bc5f',1,'classroom.c']]],
  ['podmain',['podMain',['../dice_8h.html#a3d551777c669480cfeebaf1d42d16b29',1,'dice.h']]],
  ['podtop',['podTop',['../dice_8h.html#a280fedafbecc80caa7381bb159e9a7b7',1,'dice.h']]],
  ['primitive_2eh',['primitive.h',['../primitive_8h.html',1,'']]],
  ['projection',['projection',['../classroom_8c.html#aeed201504c3705ba28fd8e9833270919',1,'classroom.c']]]
];
